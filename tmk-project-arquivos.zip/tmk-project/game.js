(function(){
  "use strict";

  // ---------------------------------------------------------------
  // SPRITES: troque SPRITE_BASE por uma URL na nuvem quando hospedar
  // as imagens (ex.: 'https://meusite.com/sprites/'). Até lá, os
  // arquivos são lidos da pasta local sprites/. Cada personagem cai
  // de volta no desenho vetorial atual automaticamente enquanto o
  // arquivo correspondente não existir, então dá pra ir soltando um
  // sprite de cada vez sem quebrar nada.
  // ---------------------------------------------------------------
  const SPRITE_BASE = 'sprites/';
  const SPRITE_FILES = {
    player: 'player.png',
    goblin: 'goblin.png',
    elite: 'elite.png',
    atirador: 'atirador.png',
    boss: 'boss.png',
  };
  const spriteImages = {};
  function loadSprites(){
    for(const key in SPRITE_FILES){
      const img = new Image();
      img.onload = ()=>{ spriteImages[key] = img; };
      img.onerror = ()=>{ /* arquivo ainda não existe: mantém o desenho vetorial */ };
      img.src = SPRITE_BASE + SPRITE_FILES[key];
    }
  }
  // desenha o sprite se ele já tiver carregado; devolve false se ainda não houver imagem,
  // para a função de desenho original assumir com as formas vetoriais de sempre
  function drawSpriteIfLoaded(g, key, x, y, size, facing, hit){
    const img = spriteImages[key];
    if(!img) return false;
    g.save();
    g.translate(x,y);
    if(facing<0) g.scale(-1,1);
    g.drawImage(img, -size/2, -size/2, size, size);
    if(hit){
      g.globalCompositeOperation='source-atop';
      g.fillStyle='rgba(255,255,255,0.6)';
      g.fillRect(-size/2,-size/2,size,size);
      g.globalCompositeOperation='source-over';
    }
    g.restore();
    return true;
  }
  loadSprites();

  // ---------------------------------------------------------------
  // NOTA DE ARQUITETURA (fase blockchain futura):
  // cada instância de arma tem um uid próprio (linha ~ makeWeaponInstance),
  // o que facilita mapear futuramente 1 arma do jogo para 1 NFT.
  // `coins` e `totalGoldEarned` seguem como candidatos a token fungível.
  // ---------------------------------------------------------------
  function stubRegisterRunOnChain(summary){
    console.log("[stub blockchain] resumo da run pronto para assinatura futura:", summary);
  }

  const canvas = document.getElementById('game');
  const ctx = canvas.getContext('2d');
  const PIXEL = 3;
  const low = document.createElement('canvas');
  const lowCtx = low.getContext('2d');
  let W, H;
  function resize(){
    W = canvas.width = window.innerWidth;
    H = canvas.height = window.innerHeight;
    low.width = Math.ceil(W/PIXEL);
    low.height = Math.ceil(H/PIXEL);
    lowCtx.imageSmoothingEnabled = false;
    ctx.imageSmoothingEnabled = false;
  }
  window.addEventListener('resize', resize);
  resize();

  // ================= dados =================
  const WEAPON_DB = [
    // ---- Arma Branca ----
    { id:'espada',              name:'Espada',                tag:'melee',     behavior:'arc',        dmg:7,  cd:0.70, range:70, arcDeg:180 },
    { id:'machado',             name:'Machado',               tag:'melee',     behavior:'knockback',  dmg:12, cd:1.15, range:65, knockback:36 },
    { id:'lanca',               name:'Lança',                 tag:'melee',     behavior:'line',       dmg:6,  cd:0.55, range:100, lineWidth:26 },
    { id:'martelo',             name:'Martelo',                tag:'melee',     behavior:'slam',       dmg:16, cd:1.60, range:80 },
    { id:'foice',               name:'Foice',                 tag:'melee',     behavior:'spin',       dmg:3,  cd:0.35, range:60 },
    { id:'faca',                name:'Faca',                  tag:'melee',     behavior:'bleed',      dmg:5,  cd:0.45, range:45, bleedDmg:2, bleedDuration:3 },
    // ---- Arma de fogo ----
    { id:'arco_longo',          name:'Arco Longo',            tag:'gunner',    behavior:'pierce_shot', dmg:8,  cd:0.85, projSpeed:460, pierce:3 },
    { id:'arcabuz',             name:'Arcabuz',               tag:'gunner',    behavior:'rapid_shot',  dmg:3,  cd:0.22, projSpeed:600, pierce:0 },
    { id:'besta_pesada',        name:'Besta Pesada',          tag:'gunner',    behavior:'heavy_shot',  dmg:20, cd:1.70, projSpeed:520, pierce:0 },
    { id:'pistola',             name:'Pistola',               tag:'gunner',    behavior:'nearest_shot',dmg:6,  cd:0.55, projSpeed:560, pierce:0 },
    { id:'rifle',               name:'Rifle',                 tag:'gunner',    behavior:'sniper_shot', dmg:9,  cd:0.90, projSpeed:750, pierce:1, critBonus:0.25 },
    { id:'escopeta',            name:'Escopeta',              tag:'gunner',    behavior:'cone_shot',   dmg:4,  cd:1.00, projSpeed:420, pierce:0, count:5, spread:0.6 },
    // ---- Magia ----
    { id:'orbe_arcano',         name:'Orbe Arcano',           tag:'elemental', behavior:'homing',      dmg:4,  cd:0.90, projSpeed:380, pierce:2 },
    { id:'cajado_gelo',         name:'Cajado de Gelo',        tag:'elemental', behavior:'freeze',      dmg:4,  cd:1.00, projSpeed:340, pierce:1, slowFactor:0.4, slowDuration:2 },
    { id:'cajado_fogo',         name:'Cajado de Fogo',        tag:'elemental', behavior:'burn',        dmg:4,  cd:0.95, projSpeed:360, pierce:1, burnDmg:2, burnDuration:3 },
    { id:'cajado_raio',         name:'Cajado de Raio',        tag:'elemental', behavior:'chain',       dmg:5,  cd:1.10, projSpeed:500, jumps:4, jumpRadius:150 },
    { id:'totem_elemental',     name:'Totem Elemental',       tag:'elemental', behavior:'totem',       dmg:5,  cd:6.00, range:150, totemFireCd:0.9, totemDuration:8 },
    { id:'esfera_vazio',        name:'Esfera do Vazio',       tag:'elemental', behavior:'vortex',      dmg:10, cd:1.80, projSpeed:300, pullRadius:110, pullDuration:0.8, explosionRadius:70 },
    // ---- Explosivos ----
    { id:'bomba_polvora',       name:'Bomba de Pólvora',      tag:'heavy',     behavior:'explosion',   dmg:14, cd:1.70, projSpeed:260, explosionRadius:55 },
    { id:'canhao_portatil',     name:'Canhão Portátil',       tag:'heavy',     behavior:'explosion',   dmg:20, cd:2.30, projSpeed:290, explosionRadius:70 },
    { id:'foguete',             name:'Foguete',               tag:'heavy',     behavior:'explosion',   dmg:24, cd:2.00, projSpeed:560, explosionRadius:65 },
    { id:'bomba_fragmentacao',  name:'Bomba de Fragmentação', tag:'heavy',     behavior:'cluster',     dmg:12, cd:2.10, projSpeed:280, explosionRadius:50, fragments:5, fragRadius:30, fragDmgMult:0.5 },
    { id:'mina',                name:'Mina',                  tag:'heavy',     behavior:'mine',        dmg:18, cd:2.40, triggerRadius:22, explosionRadius:55 },
    { id:'barril_explosivo',    name:'Barril Explosivo',      tag:'heavy',     behavior:'barrel',      dmg:22, cd:3.20, triggerRadius:26, explosionRadius:70 },
  ];
  const LEGENDARY_WEAPONS = [
    { id:'excalibur',           name:'Excalibur',             tag:'melee',     behavior:'excalibur',   dmg:20, cd:0.55, range:85, arcDeg:180, waveDmgMult:0.6 },
    { id:'metralhadora_ana',    name:'Metralhadora Anã',      tag:'gunner',    behavior:'minigun',     dmg:2,  cd:0.06, projSpeed:640, spread:0.4 },
    { id:'grimorio_proibido',   name:'Grimório Proibido',     tag:'elemental', behavior:'grimoire',    dmg:6,  cd:0.80, projSpeed:400 },
    { id:'nucleo_instavel',     name:'Núcleo Instável',       tag:'heavy',     behavior:'unstable_core',dmg:16, cd:1.60, radius:90, chainChance:0.35 },
  ];
  const LEGENDARY_COLOR = '#ff3b6f';
  const BEHAVIOR_HINT = {
    arc:'arco frontal de 180°', knockback:'empurra ao acertar', line:'perfura em linha reta',
    slam:'impacto em área', spin:'gira continuamente', bleed:'causa sangramento',
    pierce_shot:'atravessa vários inimigos', rapid_shot:'cadência muito alta', heavy_shot:'dano pesado, cadência lenta',
    nearest_shot:'mira o inimigo mais próximo', sniper_shot:'alcance enorme, crítico alto', cone_shot:'dispara em cone',
    homing:'projétil perseguidor', freeze:'reduz a velocidade do alvo', burn:'causa queimadura',
    chain:'salta entre inimigos', totem:'invoca um totem', vortex:'atrai antes de explodir',
    explosion:'explode em área', cluster:'gera mini-explosões',
    mine:'fica no chão até um inimigo passar', barrel:'fica no chão até um inimigo passar',
    excalibur:'dispara ondas de energia a cada golpe', minigun:'chuva de projéteis rápidos e imprecisos',
    grimoire:'lança feitiços aleatórios', unstable_core:'explosões em cadeia enquanto houver inimigos por perto',
  };
  const LEVEL_DMG_MULT = [1, 1.5, 2.2, 3.2];
  const LEVEL_CD_MULT  = [1, 0.95, 0.90, 0.85];
  const LEVEL_COLOR = ['var(--lv1)','var(--lv2)','var(--lv3)','var(--lv4)'];
  const TAG_LABEL = { melee:'Branca', gunner:'Fogo', elemental:'Magia', heavy:'Explosivo' };
  const TAG_COLOR = { melee:'#e0763a', gunner:'#e0c93a', elemental:'#8a6fe0', heavy:'#e05a5a' };

  const SYNERGY = {
    melee:     [ {n:2,maxHp:8,armor:3,dmg:0.05}, {n:4,maxHp:15,armor:5,dmg:0.10}, {n:6,maxHp:25,armor:9,dmg:0.18} ],
    gunner:    [ {n:2,dmg:0.05,as:0.04,range:0.08}, {n:4,dmg:0.10,as:0.08,range:0.15}, {n:6,dmg:0.18,as:0.14,range:0.25} ],
    elemental: [ {n:2,dmg:0.05,status:0.04}, {n:4,dmg:0.10,status:0.08}, {n:6,dmg:0.18,status:0.14} ],
    heavy:     [ {n:2,critDmg:0.08,radius:5,knock:1}, {n:4,critDmg:0.15,radius:10,knock:2}, {n:6,critDmg:0.25,radius:18,knock:3} ],
  };

  // costFraction = fração do ouro de referência daquela onda (não um valor fixo em ouro),
  // assim o preço acompanha proporcionalmente o quanto o jogo já gerou de ouro até ali
  const STAT_ITEMS = [
    { id:'armor1',      name:'Elmo de Ferro',        costFraction:0.50, desc:'+4 de Armadura', apply:s=>{ s.armor+=4; } },
    { id:'vit1',        name:'Poção de Vitalidade',  costFraction:0.60, desc:'+10 de Vida Máxima e cura total', heal:true, apply:s=>{ s.maxHp+=10; } },
    { id:'boots1',      name:'Botas Rápidas',        costFraction:0.50, desc:'+4% de velocidade de movimento', apply:s=>{ s.moveSpeed*=1.04; } },
    { id:'crit1',       name:'Foco Certeiro',        costFraction:0.70, desc:'+3% de chance de crítico', apply:s=>{ s.critChance+=0.03; } },
    { id:'critdmg1',    name:'Golpe Fatal',          costFraction:0.70, desc:'+12% de dano crítico', apply:s=>{ s.critDamage+=0.12; } },
    { id:'as1',         name:'Fôlego de Batalha',    costFraction:0.60, desc:'+5% de velocidade de ataque', apply:s=>{ s.attackSpeed+=0.05; } },
    { id:'ls1',         name:'Vampirismo',           costFraction:0.85, desc:'+2% de roubo de vida por golpe', apply:s=>{ s.lifeSteal+=0.02; } },
    { id:'dodge1',      name:'Reflexos',             costFraction:0.85, desc:'+3% de esquiva (máx. 60%)', apply:s=>{ s.dodge=Math.min(0.6,s.dodge+0.03); } },
    { id:'regen1',      name:'Regeneração Natural',  costFraction:0.60, desc:'+0,5 de regeneração de vida por segundo', apply:s=>{ s.hpRegen+=0.5; } },
    { id:'luck1',       name:'Amuleto da Sorte',     costFraction:0.60, desc:'+4 de sorte, melhora a loja e drops de cura', apply:s=>{ s.luck+=4; } },
    { id:'harvest1',    name:'Bolsos Fundos',        costFraction:0.60, desc:'+10% de ouro dropado por inimigos', apply:s=>{ s.goldMult*=1.1; } },
    { id:'meleedmg1',   name:'Fúria Corpo a Corpo',  costFraction:0.55, desc:'+6% de dano branco', apply:s=>{ s.meleeDmgMult+=0.06; } },
    { id:'rangeddmg1',  name:'Pólvora Refinada',     costFraction:0.55, desc:'+6% de dano de fogo', apply:s=>{ s.rangedDmgMult+=0.06; } },
    { id:'magicdmg1',   name:'Runas Arcanas',        costFraction:0.55, desc:'+6% de dano mágico', apply:s=>{ s.magicDmgMult+=0.06; } },
  ];
  const LEVEL_COST_FRACTION = [0.35, 0.65, 1.05, 1.65];

  // metade da largura/altura da arena jogável, em pixels de mundo — ajuste este valor
  // para deixar a área maior ou menor conforme a experiência de jogo
  const ARENA_HALF = 720;

  // ================= estado global =================
  let state = 'idle'; // idle | arena | shop | over | victory
  let paused = false;
  let lastTime = 0;
  let runSeed = 0;

  const keys = {};
  window.addEventListener('keydown', e => {
    keys[e.key.toLowerCase()] = true;
    if(e.key === 'Escape' && state==='arena') togglePause();
  });
  window.addEventListener('keyup', e => { keys[e.key.toLowerCase()] = false; });

  const player = { x:0, y:0, radius:15, facing:1, hp:100, maxHp:100, invuln:0, weaponSlots:[] };
  const stats = { meleeDmgMult:1, rangedDmgMult:0.5, magicDmgMult:0.5, heavyDmgMult:1, attackSpeed:0, critChance:0.05, critDamage:1.5,
    maxHp:100, armor:0, hpRegen:0, lifeSteal:0, dodge:0, moveSpeed:200, luck:0, goldMult:1 };
  let eff = null;

  let enemies=[], projectiles=[], enemyProjectiles=[], coinsPickup=[], healOrbs=[], chests=[], particles=[], slashes=[];
  let summons=[], traps=[];
  let coins=0, totalGoldEarned=0, chestsOpened=0, chestsHeld=0;
  let waveNumber=1, waveDuration=60, waveTimeLeft=60, spawnTimer=0, regenTimer=1;
  let shopOffers=[null,null,null,null], rerollCost=20;

  // ================= curvas de onda =================
  // duração: 20s na onda 1, 60s na onda 10, 90s na onda 20, 120s na onda 30,
  // interpolação linear proporcional entre cada marco, arredondada ao inteiro mais próximo
  function waveDurationFor(n){
    let dur;
    if(n<=10) dur = 20 + (n-1)*(40/9);
    else if(n<=20) dur = 60 + (n-10)*3;
    else dur = 90 + (n-20)*3;
    return Math.round(dur);
  }
  // ouro de referência da onda: quanto uma partida bem jogada tende a gerar naquela onda,
  // usado como base proporcional tanto para o ouro solto quanto para o preço dos itens da loja
  function referenceIncome(n){
    const goldPerSecond = 0.9 + (n-1)*0.16;
    return Math.round(goldPerSecond * waveDurationFor(n));
  }
  function killGoldMult(n){ return 1 + (n-1)*0.06; }
  function isBossWave(n){ return n % 10 === 0; }
  function maxAliveForWave(n){ if(n<=5) return 10; if(n<=20) return 22; return 40; }
  const SPAWN_RATE_MULT = 1.33; // +33% de geração de inimigos
  const ENEMY_SPEED_MULT = 1.25; // +25% de velocidade dos inimigos
  function spawnIntervalForWave(n){ return Math.max(0.16, 0.9 - n*0.022)/SPAWN_RATE_MULT; }
  function pickEnemyKindForWave(n){
    if(n<3) return 'goblin';
    if(n<6){ const r=Math.random(); return r<0.75 ? 'goblin' : 'atirador'; }
    const r=Math.random();
    if(n<=20) return r<0.5 ? 'goblin' : (r<0.8 ? 'elite' : 'atirador');
    return r<0.35 ? 'goblin' : (r<0.70 ? 'elite' : 'atirador');
  }
  function bossStatsForWave(n){
    const tier = n>=30 ? 3 : (n>=20 ? 2 : 1);
    const hp=[0,420,900,1700][tier], dmg=[0,20,32,48][tier], speed=(70+tier*6)*ENEMY_SPEED_MULT, radius=30+tier*3;
    return { hp, speed, damage:dmg, radius };
  }
  function baseEnemyStats(n, kind){
    const f = 1 + (n-1)*0.09;
    if(kind==='boss'){
      const ref = referenceIncome(n);
      return { ...bossStatsForWave(n), gold:[Math.round(ref*0.35), Math.round(ref*0.55)] };
    }
    if(kind==='atirador') return { hp:22*f, speed:90*ENEMY_SPEED_MULT, damage:9*f, radius:11, gold:[2,4], preferredRange:230, fireCd:1.6 };
    if(kind==='elite') return { hp:30*f, speed:96*ENEMY_SPEED_MULT, damage:11*f, radius:13, gold:[1,3] };
    return { hp:14*f, speed:110*ENEMY_SPEED_MULT, damage:6*f, radius:10, gold:[0,2] }; // goblin
  }

  // ================= armas: fábrica e fusão =================
  function makeWeaponInstance(baseId, level){
    const base = WEAPON_DB.find(w=>w.id===baseId);
    const dmgM = LEVEL_DMG_MULT[level-1], cdM = LEVEL_CD_MULT[level-1];
    const inst = Object.assign({}, base);
    inst.uid = Math.random().toString(36).slice(2);
    inst.baseId = baseId; inst.level = level; inst.timer = 0; inst.legendary = false;
    inst.damage = base.dmg*dmgM; inst.cooldown = base.cd*cdM;
    return inst;
  }
  function makeLegendaryInstance(legId){
    const L = LEGENDARY_WEAPONS.find(l=>l.id===legId);
    const inst = Object.assign({}, L);
    inst.uid = Math.random().toString(36).slice(2);
    inst.baseId = legId; inst.level = 4; inst.timer = 0; inst.legendary = true;
    inst.damage = L.dmg; inst.cooldown = L.cd;
    return inst;
  }
  function canAcquireLegendary(legId){
    if(player.weaponSlots.some(w=>w.legendary && w.baseId===legId)) return false;
    return player.weaponSlots.length<6;
  }
  function canPurchaseWeapon(baseId, level){
    if(player.weaponSlots.length<6) return true;
    return player.weaponSlots.some(w=>w.baseId===baseId && w.level===level && level<4);
  }
  function mergeWeapons(i,j){
    const a=player.weaponSlots[i], b=player.weaponSlots[j];
    if(!a || !b || a.legendary || b.legendary || a.baseId!==b.baseId || a.level!==b.level || a.level>=4) return;
    const newLevel=a.level+1;
    const hi=Math.max(i,j), lo=Math.min(i,j);
    player.weaponSlots.splice(hi,1); player.weaponSlots.splice(lo,1);
    player.weaponSlots.push(makeWeaponInstance(a.baseId,newLevel));
    recomputeEffectiveStats(); renderSlotsBar();
    if(state==='shop'){ renderShop(); updateHUD(); }
  }
  function computeMergePairs(){
    const mergePairs={};
    const groups={};
    player.weaponSlots.forEach((w,idx)=>{
      if(w.legendary) return;
      const key=w.baseId+'|'+w.level;
      (groups[key]=groups[key]||[]).push(idx);
    });
    for(const key in groups){
      const idxs=groups[key];
      const level=player.weaponSlots[idxs[0]].level;
      if(idxs.length>=2 && level<4){ mergePairs[idxs[0]]=idxs[1]; mergePairs[idxs[1]]=idxs[0]; }
    }
    return mergePairs;
  }

  // ================= sinergias e stats efetivos =================
  function getActiveSynergyTier(tag){
    const count = player.weaponSlots.filter(w=>w.tag===tag).length;
    const tiers = SYNERGY[tag];
    let active=null;
    for(const t of tiers){ if(count>=t.n) active=t; }
    return active;
  }
  function computeEffectiveStatsRaw(){
    const s = Object.assign({}, stats);
    s.gunnerRangeMult = 1; s.statusChance = 0; s.knockback = 0;
    for(const tag of ['melee','gunner','elemental','heavy']){
      const tier = getActiveSynergyTier(tag);
      if(!tier) continue;
      if(tag==='melee'){ s.maxHp+=tier.maxHp; s.armor+=tier.armor; s.meleeDmgMult*=(1+tier.dmg); }
      if(tag==='gunner'){ s.rangedDmgMult*=(1+tier.dmg); s.attackSpeed+=tier.as; s.gunnerRangeMult=1+tier.range; }
      if(tag==='elemental'){ s.magicDmgMult*=(1+tier.dmg); s.statusChance+=tier.status; }
      if(tag==='heavy'){ s.critDamage+=tier.critDmg; s.knockback+=tier.knock; }
    }
    s.magnet = 60 + s.luck*1.2;
    return s;
  }
  function synergyTierDesc(tag, tier){
    if(tag==='melee') return `+${tier.maxHp} vida máxima, +${tier.armor} armadura, +${Math.round(tier.dmg*100)}% dano branco`;
    if(tag==='gunner') return `+${Math.round(tier.dmg*100)}% dano de fogo, +${Math.round(tier.as*100)}% velocidade de ataque, +${Math.round(tier.range*100)}% alcance`;
    if(tag==='elemental') return `+${Math.round(tier.dmg*100)}% dano mágico, +${Math.round(tier.status*100)}% chance de queimadura`;
    if(tag==='heavy') return `+${Math.round(tier.critDmg*100)}% dano crítico, +${tier.radius} de raio de explosão, +${tier.knock} de impacto`;
    return '';
  }
  function renderSynergyPanel(){
    const box=document.getElementById('synergyTable');
    box.innerHTML='';
    const counts={melee:0, gunner:0, elemental:0, heavy:0};
    for(const w of player.weaponSlots) counts[w.tag]++;
    for(const tag of ['melee','gunner','elemental','heavy']){
      const tiers=SYNERGY[tag];
      const count=counts[tag];
      const active=getActiveSynergyTier(tag);
      const nextTier=tiers.find(t=>t.n>count);
      const row=document.createElement('div');
      row.className='synRow';
      row.style.borderLeftColor=TAG_COLOR[tag];
      const activeDesc = active ? synergyTierDesc(tag,active) : 'nenhum bônus ativo ainda';
      const nextDesc = nextTier ? `próximo em ${nextTier.n} armas: ${synergyTierDesc(tag,nextTier)}` : 'nível máximo de conjunto atingido';
      row.innerHTML = `
        <div class="synHeader">
          <span class="synTagName" style="color:${TAG_COLOR[tag]}">${TAG_LABEL[tag]}</span>
          <span class="synCount">${count}/6 equipadas</span>
        </div>
        <div class="synActive ${active?'on':''}">${activeDesc}</div>
        <div class="synNext">${nextDesc}</div>
      `;
      box.appendChild(row);
    }
  }
  function recomputeEffectiveStats(){
    eff = computeEffectiveStatsRaw();
    player.maxHp = eff.maxHp;
    if(player.hp>player.maxHp) player.hp=player.maxHp;
  }

  // ================= loja =================
  function rollLevel(){
    const baseWeights=[55,28,12,5];
    const luck=stats.luck||0;
    const weights=baseWeights.map((w,i)=> i===0 ? Math.max(8,w-luck*0.5) : w+luck*(i*0.35));
    const total=weights.reduce((a,b)=>a+b,0);
    let r=Math.random()*total;
    for(let i=0;i<weights.length;i++){ r-=weights[i]; if(r<=0) return i+1; }
    return 1;
  }
  function weaponOfferCost(level){ return Math.max(4, Math.round(referenceIncome(waveNumber)*LEVEL_COST_FRACTION[level-1])); }
  function statOfferCost(item){ return Math.max(4, Math.round(referenceIncome(waveNumber)*item.costFraction)); }
  function weaponDesc(base,level){
    const dmg=Math.round(base.dmg*LEVEL_DMG_MULT[level-1]);
    const cd=(base.cd*LEVEL_CD_MULT[level-1]).toFixed(2);
    const hint=BEHAVIOR_HINT[base.behavior]||'';
    return `${TAG_LABEL[base.tag]} · dano ${dmg} · cadência ${cd}s${hint?' · '+hint:''}`;
  }
  function legendaryDesc(L){
    const hint=BEHAVIOR_HINT[L.behavior]||'';
    return `Lendária · ${TAG_LABEL[L.tag]} · dano ${L.dmg} · cadência ${L.cd}s${hint?' · '+hint:''} · não pode ser aprimorada`;
  }
  function legendaryOfferCost(){ return Math.max(20, Math.round(referenceIncome(waveNumber)*2.2)); }
  function generateOffer(){
    const eligibleLeg = LEGENDARY_WEAPONS.filter(l=>canAcquireLegendary(l.id));
    if(waveNumber>=6 && eligibleLeg.length>0 && Math.random()<0.05){
      const leg=eligibleLeg[Math.floor(Math.random()*eligibleLeg.length)];
      return { type:'legendary', legId:leg.id, name:leg.name, tag:leg.tag, cost:legendaryOfferCost(),
        desc:legendaryDesc(leg), locked:false, purchased:false };
    }
    if(Math.random()<0.55){
      let attempts=0, baseId, level;
      do{ baseId=WEAPON_DB[Math.floor(Math.random()*WEAPON_DB.length)].id; level=rollLevel(); attempts++; }
      while(!canPurchaseWeapon(baseId,level) && attempts<12);
      if(canPurchaseWeapon(baseId,level)){
        const base=WEAPON_DB.find(w=>w.id===baseId);
        return { type:'weapon', baseId, level, tag:base.tag, name:base.name, cost:weaponOfferCost(level),
          desc:weaponDesc(base,level), locked:false, purchased:false };
      }
      // inventario cheio sem nenhuma combinação de arma que caiba ou funda: cai para uma melhoria
    }
    const item=STAT_ITEMS[Math.floor(Math.random()*STAT_ITEMS.length)];
    return { type:'stat', statId:item.id, name:item.name, cost:statOfferCost(item),
      desc:item.desc, locked:false, purchased:false };
  }
  function fillEmptyOffers(){ for(let i=0;i<4;i++){ if(!shopOffers[i]) shopOffers[i]=generateOffer(); } }
  function rollChestReward(){
    const eligibleLeg = LEGENDARY_WEAPONS.filter(l=>canAcquireLegendary(l.id));
    if(waveNumber>=8 && eligibleLeg.length>0 && Math.random()<0.03){
      const leg=eligibleLeg[Math.floor(Math.random()*eligibleLeg.length)];
      return { type:'legendary', legId:leg.id, name:leg.name, tag:leg.tag, desc:legendaryDesc(leg) };
    }
    if(Math.random()<0.55){
      let attempts=0, baseId, level;
      do{ baseId=WEAPON_DB[Math.floor(Math.random()*WEAPON_DB.length)].id; level=rollLevel(); attempts++; }
      while(!canPurchaseWeapon(baseId,level) && attempts<12);
      if(canPurchaseWeapon(baseId,level)){
        const base=WEAPON_DB.find(w=>w.id===baseId);
        return { type:'weapon', baseId, level, name:base.name, tag:base.tag, desc:weaponDesc(base,level) };
      }
    }
    const item=STAT_ITEMS[Math.floor(Math.random()*STAT_ITEMS.length)];
    return { type:'stat', statId:item.id, name:item.name, desc:item.desc };
  }
  function applyChestReward(reward){
    if(reward.type==='legendary'){
      if(canAcquireLegendary(reward.legId)) player.weaponSlots.push(makeLegendaryInstance(reward.legId));
    } else if(reward.type==='weapon'){
      if(player.weaponSlots.length>=6){
        const idx=player.weaponSlots.findIndex(w=>w.baseId===reward.baseId && w.level===reward.level && w.level<4);
        if(idx>=0){ player.weaponSlots.splice(idx,1); player.weaponSlots.push(makeWeaponInstance(reward.baseId, reward.level+1)); }
      } else {
        player.weaponSlots.push(makeWeaponInstance(reward.baseId, reward.level));
      }
    } else {
      const item=STAT_ITEMS.find(s=>s.id===reward.statId);
      item.apply(stats);
      if(item.heal) player.hp=player.maxHp;
    }
    recomputeEffectiveStats();
  }
  function chestRewardSellPrice(reward){
    if(reward.type==='legendary'){ return Math.max(6, Math.round(legendaryOfferCost()*0.5)); }
    if(reward.type==='weapon'){
      return Math.max(2, Math.round(weaponOfferCost(reward.level)*0.5));
    }
    const item=STAT_ITEMS.find(s=>s.id===reward.statId);
    return Math.max(2, Math.round(statOfferCost(item)*0.5));
  }

  // ================= tela de revelação de baú =================
  let chestQueueTotal=0, chestQueueIndex=0, currentChestReward=null;
  function openChestRevealScreen(){
    state='chestReveal';
    chestQueueTotal=chestsHeld; chestQueueIndex=0; chestsHeld=0;
    updateHUD();
    showNextChestInQueue();
  }
  function showNextChestInQueue(){
    chestQueueIndex++;
    currentChestReward=null;
    document.getElementById('chestRevealCounter').textContent = `Baú ${chestQueueIndex} de ${chestQueueTotal}`;
    document.getElementById('chestRevealResult').style.display='none';
    document.getElementById('btnOpenChest').style.display='inline-block';
    document.getElementById('chestRevealPanel').classList.add('show');
  }
  function advanceChestQueue(){
    document.getElementById('chestRevealPanel').classList.remove('show');
    if(chestQueueIndex<chestQueueTotal){ showNextChestInQueue(); } else { openShop(); }
  }
  document.getElementById('btnOpenChest').onclick = ()=>{
    currentChestReward = rollChestReward();
    document.getElementById('chestRevealResult').style.display='block';
    document.getElementById('chestRevealName').textContent = currentChestReward.name;
    document.getElementById('chestRevealDesc').textContent = currentChestReward.desc;
    document.getElementById('btnOpenChest').style.display='none';
    document.getElementById('btnSellChestItem').textContent = `Vender (${chestRewardSellPrice(currentChestReward)})`;
  };
  document.getElementById('btnKeepChestItem').onclick = ()=>{
    if(currentChestReward){ applyChestReward(currentChestReward); chestsOpened++; renderSlotsBar(); updateHUD(); }
    advanceChestQueue();
  };
  document.getElementById('btnSellChestItem').onclick = ()=>{
    if(currentChestReward){
      const price = chestRewardSellPrice(currentChestReward);
      coins += price; totalGoldEarned += price; chestsOpened++;
      updateHUD();
    }
    advanceChestQueue();
  };

  // encerra a onda: recolhe ouro do chao, limpa os inimigos restantes e decide entre
  // a tela de baus ou ir direto para a loja
  function endWave(){
    for(const c of coinsPickup){ coins+=c.amount; totalGoldEarned+=c.amount; }
    coinsPickup=[]; enemies=[]; enemyProjectiles=[];
    if(chestsHeld>0){ openChestRevealScreen(); } else { openShop(); }
  }
  function openShop(){
    state='shop';
    renderSlotsBar();
    // itens travados continuam disponiveis na proxima onda; só os destravados (ou vazios) são renovados
    for(let i=0;i<4;i++){ if(shopOffers[i] && !shopOffers[i].locked) shopOffers[i]=null; }
    rerollCost = Math.max(4, Math.round(referenceIncome(waveNumber)*0.28));
    fillEmptyOffers();
    renderShop();
    document.getElementById('shopPanel').classList.add('show');
  }
  function reroll(){
    if(coins<rerollCost) return;
    coins-=rerollCost; rerollCost=Math.round(rerollCost*1.5);
    for(let i=0;i<4;i++){ if(shopOffers[i] && !shopOffers[i].locked) shopOffers[i]=null; }
    fillEmptyOffers(); renderShop(); updateHUD();
  }
  function applyOffer(off){
    if(off.type==='legendary'){
      if(canAcquireLegendary(off.legId)) player.weaponSlots.push(makeLegendaryInstance(off.legId));
    } else if(off.type==='weapon'){
      if(player.weaponSlots.length>=6){
        const idx=player.weaponSlots.findIndex(w=>w.baseId===off.baseId && w.level===off.level && w.level<4);
        if(idx>=0){ player.weaponSlots.splice(idx,1); player.weaponSlots.push(makeWeaponInstance(off.baseId, off.level+1)); }
      } else {
        player.weaponSlots.push(makeWeaponInstance(off.baseId, off.level));
      }
    } else {
      const item=STAT_ITEMS.find(s=>s.id===off.statId);
      item.apply(stats);
      recomputeEffectiveStats();
      if(item.heal) player.hp=player.maxHp;
      return;
    }
    recomputeEffectiveStats();
  }
  function renderShop(){
    document.getElementById('shopGoldLine').textContent = `ouro: ${coins}`;
    const rb=document.getElementById('btnReroll');
    rb.textContent = `Sortear novamente (${rerollCost})`;
    rb.disabled = coins<rerollCost;
    const row=document.getElementById('shopRow');
    row.innerHTML='';
    shopOffers.forEach((off,i)=>{
      const card=document.createElement('div');
      if(!off){ card.className='shopCard empty'; card.textContent='vazio'; row.appendChild(card); return; }
      card.className='shopCard'+(off.type==='legendary' ? ' legendary' : '');
      const tagColor = off.type==='legendary' ? LEGENDARY_COLOR : (off.type==='weapon' ? TAG_COLOR[off.tag] : '#3ddc97');
      const tagLabel = off.type==='legendary' ? 'LENDÁRIA' : (off.type==='weapon' ? `${TAG_LABEL[off.tag].toUpperCase()} · NV ${off.level}` : 'MELHORIA');
      card.innerHTML = `
        <button class="lockBtn ${off.locked?'on':''}" title="Travar slot">🔒</button>
        <span class="rarityTag" style="background:${tagColor}">${tagLabel}</span>
        <div class="itemName">${off.name}</div>
        <div class="itemDesc">${off.desc}</div>
        <div class="priceRow"><span class="price">${off.cost} ouro</span><button class="buyBtn">Comprar</button></div>
      `;
      card.querySelector('.lockBtn').onclick = ()=>{ off.locked=!off.locked; renderShop(); };
      const btn=card.querySelector('.buyBtn');
      const invalidWeapon = off.type==='weapon' && !canPurchaseWeapon(off.baseId, off.level);
      const invalidLegendary = off.type==='legendary' && !canAcquireLegendary(off.legId);
      if(invalidWeapon || invalidLegendary){ btn.disabled=true; btn.textContent='Sem espaço'; btn.title='Inventário cheio, sem par para fundir'; }
      else if(coins<off.cost){ btn.disabled=true; }
      btn.onclick = ()=>{
        if(coins<off.cost) return;
        if(off.type==='weapon' && !canPurchaseWeapon(off.baseId, off.level)) return;
        if(off.type==='legendary' && !canAcquireLegendary(off.legId)) return;
        coins-=off.cost;
        applyOffer(off);
        shopOffers[i]=null;
        renderShop(); renderSlotsBar(); updateHUD();
      };
      row.appendChild(card);
    });
    renderOwnedWeaponsForSale();
  }
  function renderOwnedWeaponsForSale(){
    const row=document.getElementById('ownedWeaponsRow');
    row.innerHTML='';
    if(player.weaponSlots.length===0){ row.innerHTML='<div class="sellEmpty">nenhuma arma no arsenal</div>'; return; }
    const mergePairs = computeMergePairs();
    player.weaponSlots.forEach((w, idx)=>{
      const sellPrice = w.legendary ? Math.max(6, Math.round(legendaryOfferCost()*0.5)) : Math.max(2, Math.round(weaponOfferCost(w.level)*0.5));
      const canMerge = !w.legendary && mergePairs[idx]!==undefined;
      const card=document.createElement('div');
      card.className='sellCard'+(w.legendary?' legendary':'');
      card.style.borderColor = w.legendary ? LEGENDARY_COLOR : TAG_COLOR[w.tag];
      card.innerHTML = `
        <div class="itemName">${w.name} · ${w.legendary?'Lendária':'Nv.'+w.level}</div>
        <div class="itemDesc">${TAG_LABEL[w.tag]}</div>
        <div class="sellActions">
          ${canMerge ? `<button class="mergeBtn">Fundir</button>` : ''}
          <button class="sellBtn">Vender (${sellPrice})</button>
        </div>
      `;
      if(canMerge){
        card.querySelector('.mergeBtn').onclick = ()=>{ mergeWeapons(idx, mergePairs[idx]); };
      }
      card.querySelector('.sellBtn').onclick = ()=>{
        player.weaponSlots.splice(idx,1);
        coins += sellPrice; totalGoldEarned += sellPrice;
        recomputeEffectiveStats();
        renderShop(); renderSlotsBar(); updateHUD();
      };
      row.appendChild(card);
    });
  }
  document.getElementById('btnReroll').onclick = reroll;
  document.getElementById('btnContinueShop').onclick = ()=>{
    document.getElementById('shopPanel').classList.remove('show');
    startWave(waveNumber+1);
    state='arena';
  };

  // ================= slots visuais =================
  function renderSlotsBar(){
    const bar=document.getElementById('slotsBar');
    bar.innerHTML='';
    const mergePairs = computeMergePairs();
    for(let i=0;i<6;i++){
      const w=player.weaponSlots[i];
      const box=document.createElement('div');
      if(!w){ box.className='slotBox empty'; box.textContent='+'; bar.appendChild(box); continue; }
      const color = w.legendary ? LEGENDARY_COLOR : TAG_COLOR[w.tag];
      box.className='slotBox'+(mergePairs[i]!==undefined ? ' mergeable':'')+(w.legendary?' legendary':'');
      box.style.borderColor=color;
      const lvColor = w.legendary ? LEGENDARY_COLOR : ['#9aa0a6','#4cc26a','#4aa3e0','#f0a63c'][w.level-1];
      const lvLabel = w.legendary ? 'LEND' : 'Nv.'+w.level;
      box.innerHTML = `<div class="slotName">${w.name.slice(0,7)}</div><div class="slotRarity" style="color:${lvColor}">${lvLabel}</div>`+
        (mergePairs[i]!==undefined ? `<div class="mergeTag">fundir</div>` : '');
      if(mergePairs[i]!==undefined){ box.onclick = ()=> mergeWeapons(i, mergePairs[i]); }
      bar.appendChild(box);
    }
  }

  // ================= onda / reset =================
  function startWave(n){
    waveNumber=n; waveDuration=waveDurationFor(n); waveTimeLeft=waveDuration; spawnTimer=0;
    if(isBossWave(n)) spawnEnemy('boss');
    updateHUD();
  }
  function resetStats(){
    stats.meleeDmgMult=1; stats.rangedDmgMult=0.5; stats.magicDmgMult=0.5; stats.heavyDmgMult=1; stats.attackSpeed=0;
    stats.critChance=0.05; stats.critDamage=1.5; stats.maxHp=100; stats.armor=0; stats.hpRegen=0;
    stats.lifeSteal=0; stats.dodge=0; stats.moveSpeed=200; stats.luck=0; stats.goldMult=1;
  }
  function reset(){
    runSeed=Math.floor(Math.random()*1e9);
    resetStats();
    player.x=0; player.y=0; player.facing=1; player.invuln=0;
    player.weaponSlots=[ makeWeaponInstance('espada',1) ];
    recomputeEffectiveStats();
    player.hp=player.maxHp;
    enemies=[]; projectiles=[]; enemyProjectiles=[]; coinsPickup=[]; healOrbs=[]; chests=[]; particles=[]; slashes=[];
    summons=[]; traps=[];
    coins=0; totalGoldEarned=0; chestsOpened=0; chestsHeld=0; regenTimer=1;
    chestQueueTotal=0; chestQueueIndex=0; currentChestReward=null;
    startWave(1);
    updateHUD(); renderSlotsBar();
  }

  // ================= spawn =================
  function spawnEnemy(kind){
    const margin=30;
    let x,y,tries=0;
    do{
      x = (Math.random()*2-1)*(ARENA_HALF-margin);
      y = (Math.random()*2-1)*(ARENA_HALF-margin);
      tries++;
    } while(Math.hypot(x-player.x,y-player.y) < 240 && tries<20);
    const s=baseEnemyStats(waveNumber, kind);
    const e = { kind, x, y, hp:s.hp, maxHp:s.hp, speed:s.speed, damage:s.damage, radius:s.radius, gold:s.gold, hitFlash:0,
      slowTimer:0, slowFactor:1, burnTimer:0, burnTickTimer:0, burnDmg:0, bleedTimer:0, bleedTickTimer:0, bleedDmg:0 };
    if(kind==='atirador'){ e.preferredRange=s.preferredRange; e.fireCd=s.fireCd; e.fireTimer=s.fireCd*Math.random(); }
    if(kind==='boss'){ e.phase='chase'; e.attackCooldown=1.4; e.dashSpeed=e.speed*5.2; }
    enemies.push(e);
  }

  // ================= combate =================
  function nearestEnemy(){
    let best=null, bd=Infinity;
    for(const e of enemies){ const d=(e.x-player.x)**2+(e.y-player.y)**2; if(d<bd){ bd=d; best=e; } }
    return best;
  }
  function angleDiff(a,b){ let d=b-a; while(d>Math.PI)d-=2*Math.PI; while(d<-Math.PI)d+=2*Math.PI; return d; }
  function aimAngle(){
    const t=nearestEnemy();
    if(t) return Math.atan2(t.y-player.y, t.x-player.x);
    return player.facing>=0 ? 0 : Math.PI;
  }
  function weaponDamage(w){
    let mult=1;
    if(w.tag==='melee') mult=eff.meleeDmgMult;
    else if(w.tag==='gunner') mult=eff.rangedDmgMult;
    else if(w.tag==='elemental') mult=eff.magicDmgMult;
    else if(w.tag==='heavy') mult=eff.heavyDmgMult;
    let dmg=w.damage*mult, isCrit=false;
    const chance=eff.critChance+(w.critBonus||0);
    if(Math.random()<chance){ dmg*=eff.critDamage; isCrit=true; }
    return { dmg, isCrit };
  }

  // ---------- disparo: armas brancas ----------
  function fireArc(w){
    const {dmg,isCrit}=weaponDamage(w);
    const center=aimAngle();
    const half=(w.arcDeg||180)*Math.PI/360;
    slashes.push({x:player.x,y:player.y,r:w.range,life:0.18,maxLife:0.18,color:w.legendary?LEGENDARY_COLOR:TAG_COLOR[w.tag],
      startAngle:center-half, endAngle:center+half});
    for(const e of enemies){
      const d=Math.hypot(e.x-player.x,e.y-player.y);
      if(d>w.range+e.radius) continue;
      const ang=Math.atan2(e.y-player.y, e.x-player.x);
      if(Math.abs(angleDiff(center,ang))>half) continue;
      e.hp-=dmg; e.hitFlash=0.12; spawnBlood(e.x,e.y);
      if(isCrit) spawnCritFx(e.x,e.y);
      if(Math.random()<eff.lifeSteal) player.hp=Math.min(player.maxHp,player.hp+1);
      if(e.hp<=0) killEnemy(e);
    }
    enemies = enemies.filter(e=>e.hp>0);
  }
  function fireKnockbackMelee(w){
    const {dmg,isCrit}=weaponDamage(w);
    slashes.push({x:player.x,y:player.y,r:w.range,life:0.2,maxLife:0.2,color:TAG_COLOR[w.tag]});
    for(const e of enemies){
      const d=Math.hypot(e.x-player.x,e.y-player.y);
      if(d>w.range+e.radius) continue;
      e.hp-=dmg; e.hitFlash=0.12; spawnBlood(e.x,e.y);
      if(isCrit) spawnCritFx(e.x,e.y);
      const kd=d||1;
      e.x += ((e.x-player.x)/kd)*(w.knockback||30);
      e.y += ((e.y-player.y)/kd)*(w.knockback||30);
      if(Math.random()<eff.lifeSteal) player.hp=Math.min(player.maxHp,player.hp+1);
      if(e.hp<=0) killEnemy(e);
    }
    enemies = enemies.filter(e=>e.hp>0);
  }
  function fireLine(w){
    const {dmg,isCrit}=weaponDamage(w);
    const a=aimAngle();
    const dirX=Math.cos(a), dirY=Math.sin(a);
    slashes.push({x:player.x+dirX*w.range/2, y:player.y+dirY*w.range/2, r:w.range/2, life:0.16, maxLife:0.16, color:TAG_COLOR[w.tag]});
    for(const e of enemies){
      const ex=e.x-player.x, ey=e.y-player.y;
      const along=ex*dirX+ey*dirY;
      if(along<0 || along>w.range+e.radius) continue;
      const perp=Math.abs(ex*dirY-ey*dirX);
      if(perp>(w.lineWidth||24)/2+e.radius) continue;
      e.hp-=dmg; e.hitFlash=0.12; spawnBlood(e.x,e.y);
      if(isCrit) spawnCritFx(e.x,e.y);
      if(Math.random()<eff.lifeSteal) player.hp=Math.min(player.maxHp,player.hp+1);
      if(e.hp<=0) killEnemy(e);
    }
    enemies = enemies.filter(e=>e.hp>0);
  }
  function fireSlam(w){
    const {dmg,isCrit}=weaponDamage(w);
    slashes.push({x:player.x,y:player.y,r:w.range,life:0.3,maxLife:0.3,color:'#ffb347'});
    for(const e of enemies){
      const d=Math.hypot(e.x-player.x,e.y-player.y);
      if(d>w.range+e.radius) continue;
      e.hp-=dmg; e.hitFlash=0.12; spawnBlood(e.x,e.y);
      if(isCrit) spawnCritFx(e.x,e.y);
      if(Math.random()<eff.lifeSteal) player.hp=Math.min(player.maxHp,player.hp+1);
      if(e.hp<=0) killEnemy(e);
    }
    enemies = enemies.filter(e=>e.hp>0);
  }
  function fireBleedMelee(w){
    const {dmg,isCrit}=weaponDamage(w);
    slashes.push({x:player.x,y:player.y,r:w.range,life:0.12,maxLife:0.12,color:'#c0304a'});
    for(const e of enemies){
      const d=Math.hypot(e.x-player.x,e.y-player.y);
      if(d>w.range+e.radius) continue;
      e.hp-=dmg; e.hitFlash=0.12; spawnBlood(e.x,e.y);
      if(isCrit) spawnCritFx(e.x,e.y);
      e.bleedTimer=w.bleedDuration||3; e.bleedTickTimer=0; e.bleedDmg=w.bleedDmg||1;
      if(Math.random()<eff.lifeSteal) player.hp=Math.min(player.maxHp,player.hp+1);
      if(e.hp<=0) killEnemy(e);
    }
    enemies = enemies.filter(e=>e.hp>0);
  }
  function fireExcalibur(w){
    fireArc(w);
    const {dmg}=weaponDamage(w);
    const a=aimAngle();
    projectiles.push({ x:player.x, y:player.y, vx:Math.cos(a)*420, vy:Math.sin(a)*420,
      dmg:dmg*(w.waveDmgMult||0.6), isCrit:false, life:1.0, pierce:99, hitSet:new Set(),
      tag:w.tag, color:LEGENDARY_COLOR });
  }

  // ---------- disparo: armas à distância (fogo, magia, explosivos) ----------
  function fireRangedGeneric(w){
    const target=nearestEnemy();
    if(!target) return;
    const baseAngle=Math.atan2(target.y-player.y, target.x-player.x);
    const count=w.count||1;
    const spread=w.spread||0;
    const rangeMult = w.tag==='gunner' ? eff.gunnerRangeMult : 1;
    for(let i=0;i<count;i++){
      const {dmg,isCrit}=weaponDamage(w);
      let offset;
      if(w.behavior==='minigun'){ offset=(Math.random()-0.5)*spread; }
      else if(count>1){ offset=-spread/2+(spread/(count-1))*i; }
      else offset=0;
      const a=baseAngle+offset;
      projectiles.push({
        x:player.x, y:player.y, vx:Math.cos(a)*w.projSpeed*rangeMult, vy:Math.sin(a)*w.projSpeed*rangeMult,
        dmg, isCrit, life:w.behavior==='minigun'?1.0:1.6, pierce:w.pierce||0, hitSet:new Set(),
        homing:w.behavior==='homing',
        slow:w.behavior==='freeze', slowFactor:w.slowFactor, slowDuration:w.slowDuration,
        burn:w.behavior==='burn', burnDmg:w.burnDmg, burnDuration:w.burnDuration,
        chain:w.behavior==='chain', jumpsLeft:w.jumps, jumpRadius:w.jumpRadius,
        vortex:w.behavior==='vortex', pullRadius:w.pullRadius, pullDuration:w.pullDuration,
        explosionRadius:w.explosionRadius||0,
        cluster:w.behavior==='cluster', fragments:w.fragments, fragRadius:w.fragRadius, fragDmgMult:w.fragDmgMult,
        tag:w.tag, color: w.legendary?LEGENDARY_COLOR:TAG_COLOR[w.tag]
      });
    }
  }
  function fireGrimoire(w){
    const target=nearestEnemy();
    if(!target) return;
    const spells=['homing','freeze','burn','chain'];
    const pick=spells[Math.floor(Math.random()*spells.length)];
    const {dmg,isCrit}=weaponDamage(w);
    const a=Math.atan2(target.y-player.y, target.x-player.x);
    projectiles.push({
      x:player.x, y:player.y, vx:Math.cos(a)*w.projSpeed, vy:Math.sin(a)*w.projSpeed,
      dmg, isCrit, life:1.6, pierce:pick==='chain'?0:1, hitSet:new Set(),
      homing:pick==='homing',
      slow:pick==='freeze', slowFactor:0.4, slowDuration:2,
      burn:pick==='burn', burnDmg:2, burnDuration:3,
      chain:pick==='chain', jumpsLeft:4, jumpRadius:150,
      tag:w.tag, color:LEGENDARY_COLOR
    });
  }
  function fireWeapon(w){
    switch(w.behavior){
      case 'arc': fireArc(w); break;
      case 'knockback': fireKnockbackMelee(w); break;
      case 'line': fireLine(w); break;
      case 'slam': fireSlam(w); break;
      case 'bleed': fireBleedMelee(w); break;
      case 'excalibur': fireExcalibur(w); break;
      case 'grimoire': fireGrimoire(w); break;
      default: fireRangedGeneric(w); break;
    }
  }

  // ---------- comportamentos especiais: giro contínuo, totem, armadilhas, núcleo instável ----------
  function spawnOrRefreshTotem(w){
    let t=summons.find(s=>s.ownerUid===w.uid);
    if(!t){ t={ ownerUid:w.uid, x:player.x, y:player.y, radius:14, fireTimer:0 }; summons.push(t); }
    else { t.x=player.x; t.y=player.y; }
    t.duration=w.totemDuration||8;
    t.fireCd=w.totemFireCd||0.9;
    t.dmgW=w;
  }
  function placeTrap(w){
    traps.push({ x:player.x, y:player.y, radius:w.triggerRadius||22, explosionRadius:w.explosionRadius||55,
      dmg:w.damage, armTimer:0.3, life:14, type:w.behavior, tag:w.tag });
  }
  function triggerUnstableCore(w){
    const nearby=enemies.some(e=>Math.hypot(e.x-player.x,e.y-player.y)<=w.radius);
    if(!nearby) return false;
    const {dmg,isCrit}=weaponDamage(w);
    for(const e of enemies){
      const d=Math.hypot(e.x-player.x,e.y-player.y);
      if(d<=w.radius){
        e.hp-=dmg; e.hitFlash=0.12; spawnBlood(e.x,e.y);
        if(isCrit) spawnCritFx(e.x,e.y);
        if(e.hp<=0) killEnemy(e);
      }
    }
    enemies = enemies.filter(e=>e.hp>0);
    spawnExplosionFx(player.x, player.y, w.radius);
    return true;
  }
  function spawnExplosionFx(x,y,r){ slashes.push({x,y,r,life:0.25,maxLife:0.25,color:'#ff8a3a'}); }
  function spawnCritFx(x,y){
    for(let i=0;i<4;i++) particles.push({ x,y, vx:(Math.random()-0.5)*180, vy:(Math.random()-0.5)*180, life:0.35, color:'#ffe27a' });
  }
  function spawnBlood(x,y){
    for(let i=0;i<5;i++) particles.push({ x,y, vx:(Math.random()-0.5)*150, vy:(Math.random()-0.5)*150, life:0.45, color:'#8fae4a' });
  }
  function applyIncomingDamage(raw){
    if(Math.random() < Math.min(0.6, eff.dodge)) return 0;
    const mitig = eff.armor/(eff.armor+80);
    return raw*(1-mitig);
  }
  function killEnemy(e){
    const mult = e.kind==='boss' ? 1 : killGoldMult(waveNumber);
    const raw = e.gold[0]+Math.random()*(e.gold[1]-e.gold[0]);
    const goldAmt = Math.max(0, Math.round(raw*mult*eff.goldMult));
    if(goldAmt>0) coinsPickup.push({x:e.x+(Math.random()-0.5)*10,y:e.y+(Math.random()-0.5)*10,amount:goldAmt,radius:4});
    const healChance=Math.min(0.15, 0.015+eff.luck*0.0015);
    if(Math.random()<healChance) healOrbs.push({x:e.x,y:e.y,radius:6,amount:8});
    const chestChance = e.kind==='boss' ? 0.22 : Math.min(0.045, 0.008+eff.luck*0.0006);
    if(Math.random()<chestChance){
      chests.push({x:e.x,y:e.y+(e.kind==='boss'?20:0),radius:12,opened:false});
    }
  }

  // ================= chefe =================
  function updateBoss(e,dt){
    if(e.phase==='chase'){
      const dx=player.x-e.x, dy=player.y-e.y, len=Math.hypot(dx,dy)||1;
      e.x+=(dx/len)*e.speed*dt; e.y+=(dy/len)*e.speed*dt;
      e.attackCooldown-=dt;
      if(e.attackCooldown<=0){
        const r=Math.random();
        if(r<0.5){ e.phase='telegraphDash'; e.phaseTimer=0.5; e.dashTarget={x:player.x,y:player.y}; }
        else if(r<0.72){ e.phase='telegraphZone'; e.phaseTimer=0.85; e.zoneTarget={x:player.x,y:player.y}; e.zoneRadius=90; }
        else { e.phase='telegraphShot'; e.phaseTimer=1.1; e.shotChargeMax=1.1; }
      }
    } else if(e.phase==='telegraphDash'){
      e.phaseTimer-=dt;
      if(e.phaseTimer<=0){
        e.phase='dash'; e.phaseTimer=0.28;
        const dx=e.dashTarget.x-e.x, dy=e.dashTarget.y-e.y, len=Math.hypot(dx,dy)||1;
        e.dashVX=(dx/len)*e.dashSpeed; e.dashVY=(dy/len)*e.dashSpeed;
      }
    } else if(e.phase==='dash'){
      e.x+=e.dashVX*dt; e.y+=e.dashVY*dt;
      e.phaseTimer-=dt;
      if(e.phaseTimer<=0){ e.phase='chase'; e.attackCooldown=1.5; }
    } else if(e.phase==='telegraphZone'){
      e.phaseTimer-=dt;
      if(e.phaseTimer<=0){
        const d=Math.hypot(player.x-e.zoneTarget.x, player.y-e.zoneTarget.y);
        if(d<e.zoneRadius && player.invuln<=0){
          const dmgTaken=applyIncomingDamage(e.damage*1.8);
          player.hp-=dmgTaken; player.invuln=0.4; spawnBlood(player.x,player.y);
        }
        e.phase='chase'; e.attackCooldown=2.6;
      }
    } else if(e.phase==='telegraphShot'){
      // durante a carga o chefe fica parado e mira continuamente o herói
      e.phaseTimer-=dt;
      e.shotAimX=player.x; e.shotAimY=player.y;
      if(e.phaseTimer<=0){
        const dx=e.shotAimX-e.x, dy=e.shotAimY-e.y, len=Math.hypot(dx,dy)||1;
        enemyProjectiles.push({ x:e.x, y:e.y, vx:(dx/len)*480, vy:(dy/len)*480, dmg:e.damage*2.2, life:2.4, charged:true });
        e.phase='chase'; e.attackCooldown=2.2;
      }
    }
  }

  // ================= HUD =================
  function fmtTime(s){ const m=Math.floor(s/60).toString().padStart(2,'0'); const ss=Math.floor(s%60).toString().padStart(2,'0'); return `${m}:${ss}`; }
  function updateHUD(){
    document.getElementById('hpFill').style.width = Math.max(0,(player.hp/player.maxHp*100))+'%';
    document.getElementById('hpLabel').textContent = `${Math.max(0,Math.round(player.hp))}/${Math.round(player.maxHp)}`;
    document.getElementById('waveNum').textContent = waveNumber;
    document.getElementById('waveTimer').textContent = fmtTime(Math.max(0,waveTimeLeft));
    document.getElementById('coinCount').textContent = coins;
    document.getElementById('chestCount').textContent = chestsHeld;
    const counts={melee:0,gunner:0,elemental:0,heavy:0};
    for(const w of player.weaponSlots) counts[w.tag]++;
    document.getElementById('waveSynergy').innerHTML =
      `<span style="color:${TAG_COLOR.melee}">B${counts.melee}</span>`+
      `<span style="color:${TAG_COLOR.gunner}">F${counts.gunner}</span>`+
      `<span style="color:${TAG_COLOR.elemental}">M${counts.elemental}</span>`+
      `<span style="color:${TAG_COLOR.heavy}">E${counts.heavy}</span>`;
    const boss=enemies.find(e=>e.kind==='boss');
    const bossBarEl=document.getElementById('bossBar');
    if(boss){ bossBarEl.style.display='flex'; document.getElementById('bossFill').style.width=Math.max(0,boss.hp/boss.maxHp*100)+'%'; }
    else { bossBarEl.style.display='none'; }
  }
  function togglePause(){
    if(state!=='arena' && !paused) return;
    paused=!paused;
    document.getElementById('pauseOverlay').classList.toggle('show', paused);
  }
  document.getElementById('pauseBtn').onclick = togglePause;
  document.getElementById('btnResume').onclick = togglePause;
  document.getElementById('btnRestartFromPause').onclick = ()=>{
    if(!window.confirm('Reiniciar a partida atual? Todo o progresso desta corrida será perdido.')) return;
    paused=false;
    document.getElementById('pauseOverlay').classList.remove('show');
    reset(); drawPortrait();
    state='arena';
  };

  let synergyReturnTo='shop';
  document.getElementById('btnShowSynergyFromPause').onclick = ()=>{
    document.getElementById('pauseOverlay').classList.remove('show');
    synergyReturnTo='pause';
    renderSynergyPanel();
    document.getElementById('synergyPanel').classList.add('show');
  };
  document.getElementById('btnShowSynergyFromShop').onclick = ()=>{
    document.getElementById('shopPanel').classList.remove('show');
    synergyReturnTo='shop';
    renderSynergyPanel();
    document.getElementById('synergyPanel').classList.add('show');
  };
  document.getElementById('btnCloseSynergy').onclick = ()=>{
    document.getElementById('synergyPanel').classList.remove('show');
    document.getElementById(synergyReturnTo==='pause' ? 'pauseOverlay' : 'shopPanel').classList.add('show');
  };

  // ================= fim de partida =================
  function endRun(result){
    state = result==='victory' ? 'victory' : 'over';
    const runSummary = { seed:runSeed, wave:waveNumber, result, goldEarned:totalGoldEarned, weapons:player.weaponSlots.length };
    stubRegisterRunOnChain(runSummary);
    const html = `
      Onda alcançada: <b>${waveNumber}</b><br>
      Ouro total conquistado: <b>${totalGoldEarned}</b><br>
      Armas equipadas: <b>${player.weaponSlots.length}/6</b><br>
      Baús abertos: <b>${chestsOpened}</b>
    `;
    if(result==='victory'){
      document.getElementById('victoryStats').innerHTML = html;
      document.getElementById('victoryPanel').classList.add('show');
    } else {
      document.getElementById('overStats').innerHTML = html;
      document.getElementById('overPanel').classList.add('show');
    }
  }

  // ================= loop principal =================
  function update(dt){
    // regeneração
    regenTimer-=dt;
    if(regenTimer<=0){ if(eff.hpRegen>0) player.hp=Math.min(player.maxHp, player.hp+eff.hpRegen); regenTimer=1; }

    // movimento
    let mx=0, my=0;
    if(keys['w']||keys['arrowup']) my-=1;
    if(keys['s']||keys['arrowdown']) my+=1;
    if(keys['a']||keys['arrowleft']) mx-=1;
    if(keys['d']||keys['arrowright']) mx+=1;
    if(mx||my){
      const len=Math.hypot(mx,my);
      player.x += (mx/len)*eff.moveSpeed*dt; player.y += (my/len)*eff.moveSpeed*dt;
      player.facing = mx<0 ? -1 : (mx>0 ? 1 : player.facing);
    }
    const arenaLimit = ARENA_HALF - player.radius;
    player.x = Math.max(-arenaLimit, Math.min(arenaLimit, player.x));
    player.y = Math.max(-arenaLimit, Math.min(arenaLimit, player.y));
    if(player.invuln>0) player.invuln-=dt;

    // onda / spawn — mesmo em ondas de chefe, o tempo continua e inimigos normais continuam surgindo
    waveTimeLeft-=dt;
    if(waveTimeLeft<=0){
      if(waveNumber>=30){ endRun('victory'); updateHUD(); return; }
      endWave(); updateHUD(); return;
    }
    spawnTimer-=dt;
    if(spawnTimer<=0 && enemies.length<maxAliveForWave(waveNumber)){
      spawnEnemy(pickEnemyKindForWave(waveNumber));
      spawnTimer=spawnIntervalForWave(waveNumber);
    }

    // armas do jogador
    for(const w of player.weaponSlots){
      if(w.behavior==='spin'){
        w.timer-=dt;
        if(w.timer<=0){
          const {dmg,isCrit}=weaponDamage(w);
          for(const e of enemies){
            const d=Math.hypot(e.x-player.x,e.y-player.y);
            if(d<=w.range+e.radius){
              e.hp-=dmg; e.hitFlash=0.12; spawnBlood(e.x,e.y);
              if(isCrit) spawnCritFx(e.x,e.y);
              if(Math.random()<eff.lifeSteal) player.hp=Math.min(player.maxHp,player.hp+1);
              if(e.hp<=0) killEnemy(e);
            }
          }
          enemies = enemies.filter(e=>e.hp>0);
          w.timer = w.cooldown/(1+eff.attackSpeed);
        }
        w.spinAngle = (w.spinAngle||0) + dt*8;
        continue;
      }
      if(w.behavior==='totem'){
        w.timer-=dt;
        if(w.timer<=0){ spawnOrRefreshTotem(w); w.timer = w.cooldown/(1+eff.attackSpeed); }
        continue;
      }
      if(w.behavior==='mine' || w.behavior==='barrel'){
        w.timer-=dt;
        if(w.timer<=0){ placeTrap(w); w.timer = w.cooldown/(1+eff.attackSpeed); }
        continue;
      }
      if(w.behavior==='unstable_core'){
        w.timer-=dt;
        if(w.timer<=0){
          const pulsed = triggerUnstableCore(w);
          w.timer = (pulsed && Math.random()<(w.chainChance||0)) ? 0.3 : w.cooldown/(1+eff.attackSpeed);
        }
        continue;
      }
      w.timer-=dt;
      if(w.timer<=0){
        fireWeapon(w);
        w.timer = w.cooldown/(1+eff.attackSpeed);
      }
    }

    // totens ativos
    for(let i=summons.length-1;i>=0;i--){
      const t=summons[i];
      t.duration-=dt;
      if(t.duration<=0){ summons.splice(i,1); continue; }
      t.fireTimer-=dt;
      if(t.fireTimer<=0){
        let target=null, bd=Infinity;
        for(const e of enemies){
          const d=(e.x-t.x)**2+(e.y-t.y)**2;
          if(d<=(t.dmgW.range||150)**2 && d<bd){ bd=d; target=e; }
        }
        if(target){
          const {dmg,isCrit}=weaponDamage(t.dmgW);
          const a=Math.atan2(target.y-t.y, target.x-t.x);
          projectiles.push({ x:t.x, y:t.y, vx:Math.cos(a)*380, vy:Math.sin(a)*380, dmg, isCrit, life:1.4,
            pierce:0, hitSet:new Set(), tag:t.dmgW.tag, color:TAG_COLOR[t.dmgW.tag] });
        }
        t.fireTimer=t.fireCd;
      }
    }

    // armadilhas (minas e barris)
    for(let i=traps.length-1;i>=0;i--){
      const tr=traps[i];
      tr.life-=dt;
      if(tr.armTimer>0) tr.armTimer-=dt;
      let triggered=false;
      if(tr.armTimer<=0){
        for(const e of enemies){
          const d=Math.hypot(e.x-tr.x,e.y-tr.y);
          if(d<=tr.radius+e.radius){ triggered=true; break; }
        }
      }
      if(triggered || tr.life<=0){
        if(triggered){
          for(const e of enemies){
            const d=Math.hypot(e.x-tr.x,e.y-tr.y);
            if(d<=tr.explosionRadius){
              e.hp-=tr.dmg; e.hitFlash=0.12; spawnBlood(e.x,e.y);
              if(e.hp<=0) killEnemy(e);
            }
          }
          enemies = enemies.filter(e=>e.hp>0);
          spawnExplosionFx(tr.x,tr.y,tr.explosionRadius);
        }
        traps.splice(i,1);
      }
    }

    // inimigos: movimento e comportamento
    for(const e of enemies){
      if(e.slowTimer>0) e.slowTimer-=dt;
      if(e.burnTimer>0){
        e.burnTimer-=dt; e.burnTickTimer-=dt;
        if(e.burnTickTimer<=0){ e.hp-=e.burnDmg; e.burnTickTimer=0.5; spawnBlood(e.x,e.y); if(e.hp<=0) killEnemy(e); }
      }
      if(e.bleedTimer>0){
        e.bleedTimer-=dt; e.bleedTickTimer-=dt;
        if(e.bleedTickTimer<=0){ e.hp-=e.bleedDmg; e.bleedTickTimer=0.5; spawnBlood(e.x,e.y); if(e.hp<=0) killEnemy(e); }
      }
      const spd = e.speed*(e.slowTimer>0?e.slowFactor:1);
      if(e.kind==='atirador'){
        const d=Math.hypot(player.x-e.x,player.y-e.y);
        if(d>e.preferredRange*0.9){ const dx=player.x-e.x,dy=player.y-e.y,len=d||1; e.x+=(dx/len)*spd*dt; e.y+=(dy/len)*spd*dt; }
        else if(d<e.preferredRange*0.6){ const dx=e.x-player.x,dy=e.y-player.y,len=d||1; e.x+=(dx/len)*spd*0.6*dt; e.y+=(dy/len)*spd*0.6*dt; }
        e.fireTimer-=dt;
        if(e.fireTimer<=0 && d<420){
          const a=Math.atan2(player.y-e.y, player.x-e.x);
          enemyProjectiles.push({x:e.x,y:e.y,vx:Math.cos(a)*260,vy:Math.sin(a)*260,dmg:e.damage,life:2.2});
          e.fireTimer=e.fireCd;
        }
      } else if(e.kind==='boss'){
        updateBoss(e,dt);
      } else {
        const dx=player.x-e.x, dy=player.y-e.y, len=Math.hypot(dx,dy)||1;
        e.x+=(dx/len)*spd*dt; e.y+=(dy/len)*spd*dt;
      }
      if(e.hitFlash>0) e.hitFlash-=dt;
      const eLimit = ARENA_HALF - e.radius;
      e.x = Math.max(-eLimit, Math.min(eLimit, e.x));
      e.y = Math.max(-eLimit, Math.min(eLimit, e.y));
    }
    enemies = enemies.filter(e=>e.hp>0);

    // colisão de contato inimigo -> jogador
    for(const e of enemies){
      const rr=e.radius+player.radius;
      const d=Math.hypot(player.x-e.x,player.y-e.y);
      if(d<rr && player.invuln<=0){
        const dmgTaken=applyIncomingDamage(e.damage);
        player.hp-=dmgTaken; player.invuln=0.5; spawnBlood(player.x,player.y);
        if(player.hp<=0){ player.hp=0; updateHUD(); endRun('defeat'); return; }
      }
    }

    // projéteis inimigos
    for(let i=enemyProjectiles.length-1;i>=0;i--){
      const p=enemyProjectiles[i];
      p.x+=p.vx*dt; p.y+=p.vy*dt; p.life-=dt;
      if(p.life<=0){ enemyProjectiles.splice(i,1); continue; }
      const d=Math.hypot(p.x-player.x,p.y-player.y);
      if(d<player.radius+5 && player.invuln<=0){
        const dmgTaken=applyIncomingDamage(p.dmg);
        player.hp-=dmgTaken; player.invuln=0.4; spawnBlood(player.x,player.y);
        enemyProjectiles.splice(i,1);
        if(player.hp<=0){ player.hp=0; updateHUD(); endRun('defeat'); return; }
      }
    }

    // projéteis do jogador
    for(let i=projectiles.length-1;i>=0;i--){
      const p=projectiles[i];

      if(p.vortex && p.vortexState==='pulling'){
        p.vortexTimer-=dt;
        for(const e of enemies){
          const dx=p.x-e.x, dy=p.y-e.y, d=Math.hypot(dx,dy)||1;
          if(d<=p.pullRadius){ e.x+=(dx/d)*140*dt; e.y+=(dy/d)*140*dt; }
        }
        if(p.vortexTimer<=0){
          for(const e of enemies){
            const d=Math.hypot(p.x-e.x,p.y-e.y);
            if(d<=p.explosionRadius){
              e.hp-=p.dmg; e.hitFlash=0.12; spawnBlood(e.x,e.y);
              if(p.isCrit) spawnCritFx(e.x,e.y);
              if(e.hp<=0) killEnemy(e);
            }
          }
          enemies = enemies.filter(e=>e.hp>0);
          spawnExplosionFx(p.x,p.y,p.explosionRadius);
          projectiles.splice(i,1);
        }
        continue;
      }

      if(p.homing){
        let target=null, bd=Infinity;
        for(const e of enemies){ if(p.hitSet.has(e)) continue; const d=(e.x-p.x)**2+(e.y-p.y)**2; if(d<bd){ bd=d; target=e; } }
        if(target){
          const desired=Math.atan2(target.y-p.y,target.x-p.x), cur=Math.atan2(p.vy,p.vx);
          const nd=cur+angleDiff(cur,desired)*0.15, spd=Math.hypot(p.vx,p.vy);
          p.vx=Math.cos(nd)*spd; p.vy=Math.sin(nd)*spd;
        }
      }
      p.x+=p.vx*dt; p.y+=p.vy*dt; p.life-=dt;
      if(p.life<=0){ projectiles.splice(i,1); continue; }
      let hitSomething=false;
      for(let j=enemies.length-1;j>=0;j--){
        const e=enemies[j];
        if(p.hitSet.has(e)) continue;
        const d=Math.hypot(p.x-e.x,p.y-e.y);
        if(d < e.radius+4){
          if(p.vortex){
            p.vortexState='pulling'; p.vortexTimer=p.pullDuration||0.8; p.vx=0; p.vy=0;
            hitSomething=true;
            break;
          }
          if(p.explosionRadius>0){
            for(const e2 of enemies){
              if(e2.hp<=0) continue;
              const d2=Math.hypot(p.x-e2.x,p.y-e2.y);
              if(d2<=p.explosionRadius){
                e2.hp-=p.dmg; e2.hitFlash=0.12; spawnBlood(e2.x,e2.y);
                if(p.isCrit) spawnCritFx(e2.x,e2.y);
                if(eff.knockback){ const kd=d2||1; e2.x+=((e2.x-p.x)/kd)*eff.knockback*8; e2.y+=((e2.y-p.y)/kd)*eff.knockback*8; }
                if(e2.hp<=0) killEnemy(e2);
              }
            }
            enemies = enemies.filter(e=>e.hp>0);
            if(p.cluster){
              for(let f=0; f<(p.fragments||0); f++){
                const fa=Math.random()*Math.PI*2, fr=Math.random()*(p.explosionRadius||40);
                const fx=p.x+Math.cos(fa)*fr, fy=p.y+Math.sin(fa)*fr;
                for(const e3 of enemies){
                  if(e3.hp<=0) continue;
                  const d3=Math.hypot(fx-e3.x,fy-e3.y);
                  if(d3<=(p.fragRadius||30)){
                    e3.hp-=p.dmg*(p.fragDmgMult||0.5); e3.hitFlash=0.12; spawnBlood(e3.x,e3.y);
                    if(e3.hp<=0) killEnemy(e3);
                  }
                }
                spawnExplosionFx(fx,fy,p.fragRadius||30);
              }
              enemies = enemies.filter(e=>e.hp>0);
            }
            if(Math.random()<eff.lifeSteal) player.hp=Math.min(player.maxHp,player.hp+1);
            spawnExplosionFx(p.x,p.y,p.explosionRadius);
            projectiles.splice(i,1);
            hitSomething=true;
          } else if(p.chain){
            e.hp-=p.dmg; e.hitFlash=0.12; spawnBlood(e.x,e.y);
            if(p.isCrit) spawnCritFx(e.x,e.y);
            if(Math.random()<eff.lifeSteal) player.hp=Math.min(player.maxHp,player.hp+1);
            p.hitSet.add(e);
            if(e.hp<=0){ killEnemy(e); enemies.splice(j,1); }
            p.jumpsLeft=(p.jumpsLeft||0)-1;
            let nextTarget=null, bd2=Infinity;
            for(const e2 of enemies){
              if(p.hitSet.has(e2)) continue;
              const d2=(e2.x-p.x)**2+(e2.y-p.y)**2;
              if(d2<=(p.jumpRadius||150)**2 && d2<bd2){ bd2=d2; nextTarget=e2; }
            }
            if(p.jumpsLeft>0 && nextTarget){
              const a=Math.atan2(nextTarget.y-p.y, nextTarget.x-p.x);
              const spd=Math.hypot(p.vx,p.vy)||400;
              p.vx=Math.cos(a)*spd; p.vy=Math.sin(a)*spd;
            } else {
              projectiles.splice(i,1); hitSomething=true;
            }
          } else {
            e.hp-=p.dmg; e.hitFlash=0.12; spawnBlood(e.x,e.y);
            if(p.isCrit) spawnCritFx(e.x,e.y);
            if(p.tag==='elemental' && Math.random()<eff.statusChance){ e.burnTimer=3; e.burnTickTimer=0; e.burnDmg=Math.max(1,Math.round(p.dmg*0.08)); }
            if(p.burn){ e.burnTimer=p.burnDuration||3; e.burnTickTimer=0; e.burnDmg=p.burnDmg||1; }
            if(p.slow){ e.slowTimer=p.slowDuration||1.5; e.slowFactor=p.slowFactor||0.5; }
            if(Math.random()<eff.lifeSteal) player.hp=Math.min(player.maxHp,player.hp+1);
            p.hitSet.add(e);
            if(p.hitSet.size > p.pierce){ projectiles.splice(i,1); hitSomething=true; }
            if(e.hp<=0){ killEnemy(e); enemies.splice(j,1); }
          }
          break;
        }
      }
      if(hitSomething) enemies = enemies.filter(e=>e.hp>0);
    }

    // moedas
    for(let i=coinsPickup.length-1;i>=0;i--){
      const c=coinsPickup[i];
      const d=Math.hypot(c.x-player.x,c.y-player.y);
      if(d<eff.magnet){ const dx=player.x-c.x,dy=player.y-c.y,len=d||1; c.x+=(dx/len)*320*dt; c.y+=(dy/len)*320*dt; }
      if(d<player.radius+6){ coins+=c.amount; totalGoldEarned+=c.amount; coinsPickup.splice(i,1); }
    }
    // orbes de cura
    for(let i=healOrbs.length-1;i>=0;i--){
      const h=healOrbs[i];
      const d=Math.hypot(h.x-player.x,h.y-player.y);
      if(d<eff.magnet){ const dx=player.x-h.x,dy=player.y-h.y,len=d||1; h.x+=(dx/len)*320*dt; h.y+=(dy/len)*320*dt; }
      if(d<player.radius+6){ player.hp=Math.min(player.maxHp, player.hp+h.amount); healOrbs.splice(i,1); }
    }
    // baús: coletar aqui apenas guarda o baú, a abertura acontece ao fim da onda
    for(const c of chests){
      if(c.opened) continue;
      const d=Math.hypot(c.x-player.x,c.y-player.y);
      if(d<player.radius+c.radius){
        c.opened=true; chestsHeld++;
      }
    }

    // partículas / slashes
    for(let i=particles.length-1;i>=0;i--){ const pt=particles[i]; pt.x+=pt.vx*dt; pt.y+=pt.vy*dt; pt.life-=dt; if(pt.life<=0) particles.splice(i,1); }
    for(let i=slashes.length-1;i>=0;i--){ slashes[i].life-=dt; if(slashes[i].life<=0) slashes.splice(i,1); }

    updateHUD();
  }

  // ================= sprites =================
  function drawGoblin(g,x,y,hit){
    if(drawSpriteIfLoaded(g,'goblin',x,y,26,1,hit)) return;
    g.fillStyle=hit?'#ffffff':'#3f8a3a'; g.beginPath(); g.arc(x,y,11,0,Math.PI*2); g.fill();
    g.fillStyle=hit?'#ffffff':'#2c6b28';
    g.beginPath(); g.moveTo(x-11,y-4); g.lineTo(x-17,y-11); g.lineTo(x-6,y-9); g.fill();
    g.beginPath(); g.moveTo(x+11,y-4); g.lineTo(x+17,y-11); g.lineTo(x+6,y-9); g.fill();
    g.fillStyle='#12200f'; g.fillRect(x-5,y-2,2.5,2.5); g.fillRect(x+2.5,y-2,2.5,2.5);
    g.fillStyle='#24421f'; g.fillRect(x-6,y+9,4,6); g.fillRect(x+2,y+9,4,6);
  }
  function drawElite(g,x,y,hit){
    if(drawSpriteIfLoaded(g,'elite',x,y,30,1,hit)) return;
    g.fillStyle=hit?'#ffffff':'#4a3f52'; g.beginPath(); g.ellipse(x,y,15,11,0,0,Math.PI*2); g.fill();
    g.fillStyle=hit?'#ffffff':'#eae4ea';
    g.beginPath(); g.moveTo(x+11,y+2); g.lineTo(x+19,y-1); g.lineTo(x+11,y+6); g.fill();
    g.fillStyle='#c23a3a'; g.fillRect(x+9,y-6,2.5,2.5);
    g.fillStyle='#2a2230'; g.fillRect(x-9,y+9,4,6); g.fillRect(x+3,y+9,4,6);
  }
  function drawAtirador(g,x,y,hit){
    if(drawSpriteIfLoaded(g,'atirador',x,y,26,1,hit)) return;
    g.fillStyle=hit?'#ffffff':'#5a6b3f'; g.beginPath(); g.arc(x,y,11,0,Math.PI*2); g.fill();
    g.fillStyle=hit?'#ffffff':'#3a4a28'; g.beginPath(); g.arc(x,y-3,9,Math.PI,2*Math.PI); g.fill();
    g.strokeStyle='#caa96a'; g.lineWidth=2;
    g.beginPath(); g.arc(x+10,y,8,-Math.PI/2.4,Math.PI/2.4); g.stroke();
    g.fillStyle='#1e2a14'; g.fillRect(x-6,y+9,4,6); g.fillRect(x+2,y+9,4,6);
  }
  function drawBoss(g,x,y,hit,e){
    if(!drawSpriteIfLoaded(g,'boss',x,y,68,1,hit)){
      g.fillStyle=hit?'#ffffff':'#3a6b3a'; g.beginPath(); g.arc(x,y,26,0,Math.PI*2); g.fill();
      g.fillStyle=hit?'#ffffff':'#2f5a2f';
      for(let i=-2;i<=2;i++){ g.beginPath(); g.moveTo(x+i*10,y-24); g.lineTo(x+i*10-5,y-38); g.lineTo(x+i*10+5,y-38); g.fill(); }
      g.fillStyle='#f4c430'; g.fillRect(x-8,y-6,4,4); g.fillRect(x+4,y-6,4,4);
      g.strokeStyle='#5c3a1f'; g.lineWidth=4; g.beginPath(); g.moveTo(x+22,y+20); g.lineTo(x+30,y-30); g.stroke();
      g.fillStyle='#f4c430'; g.shadowColor='#f4c430'; g.shadowBlur=10;
      g.beginPath(); g.arc(x+30,y-32,6,0,Math.PI*2); g.fill(); g.shadowBlur=0;
    }
    if(e){
      if(e.phase==='telegraphDash'){
        g.strokeStyle='rgba(255,60,60,0.7)'; g.lineWidth=3;
        g.beginPath(); g.moveTo(x,y); g.lineTo(x+(e.dashTarget.x-e.x), y+(e.dashTarget.y-e.y)); g.stroke();
      } else if(e.phase==='telegraphZone'){
        const prog = 1-(e.phaseTimer/0.85);
        g.strokeStyle='rgba(255,50,50,0.8)'; g.lineWidth=3;
        g.beginPath(); g.arc(x+(e.zoneTarget.x-e.x), y+(e.zoneTarget.y-e.y), e.zoneRadius*Math.max(0.15,prog), 0, Math.PI*2); g.stroke();
      } else if(e.phase==='telegraphShot'){
        const prog = 1-(e.phaseTimer/e.shotChargeMax);
        if(e.shotAimX!==undefined){
          g.strokeStyle='rgba(120,200,255,0.75)'; g.lineWidth=2;
          g.beginPath(); g.moveTo(x,y); g.lineTo(x+(e.shotAimX-e.x), y+(e.shotAimY-e.y)); g.stroke();
        }
        g.fillStyle='#a8e0ff'; g.shadowColor='#a8e0ff'; g.shadowBlur=6+prog*14;
        g.beginPath(); g.arc(x, y, 5+prog*11, 0, Math.PI*2); g.fill();
        g.shadowBlur=0;
      }
    }
  }
  function drawPlayer(g,x,y,facing,weaponSlots,invuln){
    g.save(); g.translate(x,y); g.scale(facing,1);
    if(spriteImages.player){
      g.drawImage(spriteImages.player, -16, -26, 32, 32);
      if(invuln){
        g.globalCompositeOperation='source-atop';
        g.fillStyle='rgba(255,255,255,0.6)';
        g.fillRect(-16,-26,32,32);
        g.globalCompositeOperation='source-over';
      }
    } else {
      g.fillStyle=invuln?'#ffffff':'#8a2e2e'; g.fillRect(-9,-2,18,16);
      g.fillStyle='#e7b98c'; g.beginPath(); g.arc(0,-10,10,0,Math.PI*2); g.fill();
      g.fillStyle='#2b2018'; g.beginPath(); g.arc(0,-14,9,Math.PI,2*Math.PI); g.fill();
      g.beginPath(); g.arc(-3,-22,4,0,Math.PI*2); g.fill();
      g.fillStyle=invuln?'#ffffff':'#5a2323'; g.fillRect(-8,12,6,8); g.fillRect(2,12,6,8);
    }
    const hasRanged = weaponSlots.some(w=>w.tag && w.tag!=='melee');
    if(hasRanged){ g.fillStyle='#3a3a3a'; g.fillRect(8,-2,16,4); }
    else { g.strokeStyle='#c9c9c9'; g.lineWidth=3; g.beginPath(); g.moveTo(9,4); g.lineTo(24,-10); g.stroke(); }
    g.restore();
  }

  // ================= desenho =================
  function draw(){
    lowCtx.clearRect(0,0,low.width,low.height);
    lowCtx.save(); lowCtx.scale(1/PIXEL,1/PIXEL);
    const camX=W/2-player.x, camY=H/2-player.y;

    // fora da arena: floresta densa e escura, intransponível
    lowCtx.fillStyle='#152a19'; lowCtx.fillRect(0,0,W,H);

    const arenaX = -ARENA_HALF+camX, arenaY = -ARENA_HALF+camY, arenaSize = ARENA_HALF*2;

    lowCtx.save();
    lowCtx.beginPath(); lowCtx.rect(arenaX, arenaY, arenaSize, arenaSize); lowCtx.clip();

    const bgGrad=lowCtx.createLinearGradient(0,0,0,H);
    bgGrad.addColorStop(0,'#2c5c34'); bgGrad.addColorStop(1,'#20431f');
    lowCtx.fillStyle=bgGrad; lowCtx.fillRect(0,0,W,H);

    lowCtx.strokeStyle='rgba(255,255,255,0.05)'; lowCtx.lineWidth=1;
    const gridSize=70;
    const offX=((camX%gridSize)+gridSize)%gridSize, offY=((camY%gridSize)+gridSize)%gridSize;
    for(let x=offX;x<W;x+=gridSize){ lowCtx.beginPath(); lowCtx.moveTo(x,0); lowCtx.lineTo(x,H); lowCtx.stroke(); }
    for(let y=offY;y<H;y+=gridSize){ lowCtx.beginPath(); lowCtx.moveTo(0,y); lowCtx.lineTo(W,y); lowCtx.stroke(); }
    lowCtx.restore();

    // parede da arena
    lowCtx.strokeStyle='#4a331c'; lowCtx.lineWidth=8;
    lowCtx.strokeRect(arenaX, arenaY, arenaSize, arenaSize);
    lowCtx.strokeStyle='#7a5a30'; lowCtx.lineWidth=2;
    lowCtx.strokeRect(arenaX+4, arenaY+4, arenaSize-8, arenaSize-8);

    for(const c of chests){
      if(c.opened) continue;
      lowCtx.fillStyle='#b9803f'; lowCtx.fillRect(c.x+camX-10, c.y+camY-8, 20, 14);
      lowCtx.fillStyle='#f4c430'; lowCtx.fillRect(c.x+camX-2, c.y+camY-8, 4, 6);
    }
    for(const c of coinsPickup){
      lowCtx.fillStyle='#f4c430'; lowCtx.shadowColor='#f4c430'; lowCtx.shadowBlur=5;
      lowCtx.beginPath(); lowCtx.arc(c.x+camX,c.y+camY,c.radius,0,Math.PI*2); lowCtx.fill(); lowCtx.shadowBlur=0;
    }
    for(const h of healOrbs){
      lowCtx.fillStyle='#5be07a'; lowCtx.shadowColor='#5be07a'; lowCtx.shadowBlur=8;
      lowCtx.beginPath(); lowCtx.arc(h.x+camX,h.y+camY,h.radius,0,Math.PI*2); lowCtx.fill(); lowCtx.shadowBlur=0;
    }
    for(const pt of particles){
      lowCtx.globalAlpha=Math.max(0,pt.life/0.45); lowCtx.fillStyle=pt.color;
      lowCtx.fillRect(pt.x+camX-2, pt.y+camY-2, 4,4); lowCtx.globalAlpha=1;
    }
    for(const s of slashes){
      lowCtx.globalAlpha=Math.max(0,s.life/s.maxLife)*0.55;
      lowCtx.strokeStyle=s.color||'#ffffff'; lowCtx.lineWidth=4;
      const rr=s.r*(1-s.life/s.maxLife*0.3);
      lowCtx.beginPath();
      if(s.startAngle!==undefined){ lowCtx.arc(s.x+camX, s.y+camY, rr, s.startAngle, s.endAngle); }
      else { lowCtx.arc(s.x+camX, s.y+camY, rr, 0, Math.PI*2); }
      lowCtx.stroke();
      lowCtx.globalAlpha=1;
    }
    for(const tr of traps){
      const armed = tr.armTimer<=0;
      lowCtx.fillStyle = tr.type==='barrel' ? '#8a5a2b' : '#3a2f22';
      lowCtx.beginPath(); lowCtx.arc(tr.x+camX, tr.y+camY, tr.type==='barrel'?10:7, 0, Math.PI*2); lowCtx.fill();
      if(armed){
        lowCtx.fillStyle='#ff8a3a'; lowCtx.shadowColor='#ff8a3a'; lowCtx.shadowBlur=6;
        lowCtx.beginPath(); lowCtx.arc(tr.x+camX, tr.y+camY-2, 2, 0, Math.PI*2); lowCtx.fill();
        lowCtx.shadowBlur=0;
      }
    }
    for(const t of summons){
      const tx=t.x+camX, ty=t.y+camY;
      lowCtx.fillStyle='#6a4a8a'; lowCtx.fillRect(tx-5, ty-4, 10, 16);
      lowCtx.fillStyle='#c9a8ff'; lowCtx.shadowColor='#c9a8ff'; lowCtx.shadowBlur=8;
      lowCtx.beginPath(); lowCtx.arc(tx, ty-8, 5, 0, Math.PI*2); lowCtx.fill();
      lowCtx.shadowBlur=0;
    }
    for(const e of enemies){
      const ex=e.x+camX, ey=e.y+camY;
      if(e.kind==='boss') drawBoss(lowCtx, ex, ey, e.hitFlash>0, e);
      else if(e.kind==='elite') drawElite(lowCtx, ex, ey, e.hitFlash>0);
      else if(e.kind==='atirador') drawAtirador(lowCtx, ex, ey, e.hitFlash>0);
      else drawGoblin(lowCtx, ex, ey, e.hitFlash>0);
    }
    for(const p of projectiles){
      lowCtx.save(); lowCtx.translate(p.x+camX,p.y+camY); lowCtx.rotate(Math.atan2(p.vy,p.vx));
      lowCtx.fillStyle=p.color||'#f4d35e'; lowCtx.fillRect(-5,-2,10,4); lowCtx.restore();
    }
    for(const p of enemyProjectiles){
      const col = p.charged ? '#a8e0ff' : '#e0435a';
      const rad = p.charged ? 7 : 4;
      lowCtx.fillStyle=col; lowCtx.shadowColor=col; lowCtx.shadowBlur = p.charged ? 12 : 6;
      lowCtx.beginPath(); lowCtx.arc(p.x+camX,p.y+camY,rad,0,Math.PI*2); lowCtx.fill(); lowCtx.shadowBlur=0;
    }
    drawPlayer(lowCtx, W/2, H/2, player.facing, player.weaponSlots, player.invuln>0);
    for(const w of player.weaponSlots){
      if(w.behavior==='spin'){
        const a=w.spinAngle||0;
        lowCtx.strokeStyle=w.legendary?LEGENDARY_COLOR:TAG_COLOR.melee; lowCtx.lineWidth=3;
        lowCtx.beginPath(); lowCtx.moveTo(W/2, H/2);
        lowCtx.lineTo(W/2+Math.cos(a)*w.range, H/2+Math.sin(a)*w.range); lowCtx.stroke();
        lowCtx.beginPath(); lowCtx.arc(W/2, H/2, w.range, 0, Math.PI*2);
        lowCtx.strokeStyle='rgba(224,118,58,0.25)'; lowCtx.lineWidth=1; lowCtx.stroke();
      }
    }

    const grad=lowCtx.createRadialGradient(W/2,H/2,H*0.28,W/2,H/2,H*0.78);
    grad.addColorStop(0,'rgba(0,0,0,0)'); grad.addColorStop(1,'rgba(0,10,0,0.5)');
    lowCtx.fillStyle=grad; lowCtx.fillRect(0,0,W,H);
    lowCtx.restore();

    ctx.clearRect(0,0,W,H);
    ctx.drawImage(low,0,0,low.width,low.height,0,0,W,H);
  }

  function loop(ts){
    if(!lastTime) lastTime=ts;
    const dt=Math.min(0.05,(ts-lastTime)/1000);
    lastTime=ts;
    if(state==='arena' && !paused) update(dt);
    draw();
    requestAnimationFrame(loop);
  }

  function drawPortrait(){
    const pc=document.getElementById('portraitCanvas');
    const pg=pc.getContext('2d');
    pg.imageSmoothingEnabled=false; pg.clearRect(0,0,40,40);
    drawPlayer(pg, 20, 24, 1, player.weaponSlots.length?player.weaponSlots:[{tag:'melee'}], false);
  }

  document.getElementById('btnStart').onclick = ()=>{
    reset(); drawPortrait();
    document.getElementById('startPanel').classList.remove('show');
    state='arena';
  };
  document.getElementById('btnRestart').onclick = ()=>{
    reset(); drawPortrait();
    document.getElementById('overPanel').classList.remove('show');
    state='arena';
  };
  document.getElementById('btnPlayAgain').onclick = ()=>{
    reset(); drawPortrait();
    document.getElementById('victoryPanel').classList.remove('show');
    state='arena';
  };

  requestAnimationFrame(loop);
})();
